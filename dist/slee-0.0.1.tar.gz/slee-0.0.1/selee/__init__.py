"""

This is selee package and it contains fizz_buzz in selee_moduel.py

"""
__all__ = ['selee_module']
__version__ = '0.0.1' 